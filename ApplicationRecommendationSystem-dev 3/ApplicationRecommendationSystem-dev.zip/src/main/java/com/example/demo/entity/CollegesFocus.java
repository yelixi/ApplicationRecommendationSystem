package com.example.demo.entity;

import lombok.Data;

@Data
public class CollegesFocus {
    private Integer id;

    private Integer openId;

    private String colleges;
}
