package com.example.demo.enums;

/**
 * @author 11834
 */

public enum KnowNewCollegeArea {
    上海,浙江,北京,海南,山东,天津
}
