package com.example.demo.enums;

/**
 * @author 11834
 */
public enum MajorGroup {
    江苏,湖北,湖南,广东,福建,上海,海南,天津,北京
}
