package com.example.demo.repository;

import com.example.demo.entity.neo4j.CountryMajor;
import com.example.demo.entity.neo4j.Major;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author 11834
 */
@Repository
public interface MajorRepository extends Neo4jRepository<Major, Long> {
    /**
     * 专业大类获取专业小类  --本科
     * @param category
     * @return
     */
    @Query("MATCH (p:CountryMajorClass{country_major_name:$category})-[r:INCLUDE]->(IN) RETURN IN.country_major_smallclass_name as smallClass")
    List<String> getMajorCategoryByType(@Param("category") String category);

    /**
     * 专业大类获取专业小类  --专科学校本科专业
     * @param category
     * @return
     */
    @Query("MATCH (p:CountryMajorClassZhuanKe_BenKEZhuanYe{country_major_class_name:$category})-[r:INCLUDE]->(IN) RETURN IN.country_major_smallclass_name")
    List<String> getAssociateMajorCategoryByType(@Param("category") String category);

    /**
     * 专业大类获取专业小类  --专科学校专科专业
     * @param category
     * @return
     */
    @Query("MATCH (p:CountryMajorClassZhuanKe_ZhuanKEZhuanYe{country_major_class_name:$category})-[r:INCLUDE]->(IN) RETURN IN.country_major_smallclass_name")
    List<String> getAssociateZkMajorCategoryByType(@Param("category") String category);


    /**
     * 获取国家专业    --本科
     * @param category
     * @return
     */
    @Query("MATCH (p:CountryMajorSmallClass{country_major_smallclass_name:$category})-[r:INCLUDE]->(IN) RETURN IN")
    List<CountryMajor> getCountryMajorCategoryByType(@Param("category") String category);

    /**
     * 获取国家专业    --专科学校本科专业
     * @param category
     * @return
     */
    @Query("MATCH (p:CountryMajorSmallClassZhuanKe_BenKEZhuanYe{country_major_smallclass_name:$category})-[r:INCLUDE]->(IN) RETURN IN")
    List<CountryMajor> getAssociateCountryMajorCategoryByType(@Param("category") String category);

    /**
     * 获取国家专业    --专科学校专科专业
     * @param category
     * @return
     */
    @Query("MATCH (p:CountryMajorSmallClassZhuanKe_BenKEZhuanYe{country_major_smallclass_name:$category})-[r:INCLUDE]->(IN) RETURN IN")
    List<CountryMajor> getAssociateZkCountryMajorCategoryByType(@Param("category") String category);
}
