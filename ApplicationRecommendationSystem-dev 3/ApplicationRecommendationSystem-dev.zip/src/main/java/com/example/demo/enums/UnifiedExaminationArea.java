package com.example.demo.enums;

/**
 * @author 11834
 */
public enum UnifiedExaminationArea {
    吉林,黑龙江,内蒙古,山西,河南,安徽,江西,广西,四川,云南,贵州,陕西,宁夏,甘肃,青海,新疆,西藏
}
