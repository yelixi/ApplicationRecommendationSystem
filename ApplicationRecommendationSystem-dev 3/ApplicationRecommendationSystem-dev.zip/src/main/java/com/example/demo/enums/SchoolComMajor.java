package com.example.demo.enums;

/**
 * @author 11834
 */
public enum SchoolComMajor {
    浙江,山东,河北,重庆,辽宁,
}
