package com.example.demo.util;

public class TestUtil {
    public static void main(String[] args){
        String s = "/";
        System.out.println(s == "/");
    }
}
