package com.example.demo.entity;

import lombok.Data;

@Data
public class PapersFocus {
    private Integer id;

    private Integer openId;

    private String papers;
}
