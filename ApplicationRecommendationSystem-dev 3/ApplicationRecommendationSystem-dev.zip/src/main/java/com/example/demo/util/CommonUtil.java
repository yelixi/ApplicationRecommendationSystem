package com.example.demo.util;

import com.example.demo.enums.KnowNewCollegeArea;
import com.example.demo.enums.UnifiedExaminationArea;
import com.example.demo.enums.UnknowNewCollegeArea;

/**
 * @author 11834
 */
public class CommonUtil {

    public static int examArea(String province){
        for(UnifiedExaminationArea area: UnifiedExaminationArea.values()){
            if(province.equals(area.toString())){
                return CommUtil.UNIFIED_EXAMINATION_AREA;
            }
        }
        for(UnknowNewCollegeArea area: UnknowNewCollegeArea.values()){
            if(province.equals(area.toString())){
                return CommUtil.UNKNOW_NEW_EXAMINATION_AREA;
            }
        }
        for(KnowNewCollegeArea area: KnowNewCollegeArea.values()){
            if(province.equals(area.toString())){
                return CommUtil.KNOW_NEW_EXAMINATION_AREA;
            }
        }
        return 3;
    }


}
