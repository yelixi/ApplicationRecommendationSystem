package com.example.demo.service;

import com.example.demo.entity.neo4j.CountryMajor;
import com.example.demo.entity.neo4j.Major;

import java.util.List;
import java.util.Map;

/**
 * Created by 林夕
 * Date 2021/5/10 10:14
 */
public interface MajorService {

    /**
     * 专业大类获取专业小类
     * @param category
     * @param undergraduate
     * @return
     */
    List<String> getMajorCategory(String category,boolean undergraduate);

    /**
     * 根据专业小类获取具体专业
     * @param smallCategory
     * @param undergraduate
     * @return
     */
    List<CountryMajor> getMajorSmallCategory(String smallCategory, boolean undergraduate);

    /**
     * 获取专业卡片
     * @param name
     * @return
     */
    Major getMajorCard(String name);
}
