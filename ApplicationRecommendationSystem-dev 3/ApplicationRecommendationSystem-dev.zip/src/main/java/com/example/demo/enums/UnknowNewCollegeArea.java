package com.example.demo.enums;

/**
 * @author 11834
 */
public enum UnknowNewCollegeArea {
    广东,福建,河北,辽宁,江苏,湖南,湖北,重庆
}
