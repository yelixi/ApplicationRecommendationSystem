package com.example.demo.controller;

import com.example.demo.entity.neo4j.SchoolInfo;
import com.example.demo.model.RestResult;
import com.example.demo.service.SchoolService;
import com.example.demo.service.VolunteerService;
import com.example.demo.util.CommUtil;
import com.example.demo.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Calendar;

/**
 * @author 11834
 */
@Slf4j
@RestController
@RequestMapping("/volunteer")
public class VolunteerController {

    @Autowired
    private VolunteerService volunteerService;

    @Autowired
    private SchoolService schoolService;

    /**
     * 一键填报
     * @param map
     * @return
     */
    @RequestMapping("/report")
    public RestResult<List<SchoolInfo>> reportVoluntary(@RequestBody Map<String, Object> map) {
        String province = "";
        String subject = "";
        String userName = "";
        int year = 0;
        int rank = 0;
        String chinese = "";
        String math = "";
        String english = "";
        String chemistry = "";
        String biology = "";
        String politics = "";
        String history = "";
        String geography = "";
        String technology = "";
        String comprehensiveScience = "";
        String comprehensiveLiberalArts = "";
        int totalScore = 0;
        HashMap<String, String> validScore = new HashMap<String, String>();

        if (map.get("province") != null) {
            province = map.get("province").toString();
        }
        if (map.get("userName") != null) {
            userName = map.get("userName").toString();
        }
        if (map.get("year") != null) {
            year = Integer.parseInt(map.get("year").toString());
        }
        //如果rank有非0值，则是高考成绩带有排名；否则是模拟考试成绩
        if (map.get("rank") != null && !"".equals(map.get("rank").toString())) {
            rank = Integer.parseInt(map.get("rank").toString());
        }
        if (map.get("chinese") != null) {
            chinese = map.get("chinese").toString();
            validScore.put("chinese", chinese);
        }
        if (map.get("math") != null) {
            math = map.get("math").toString();
            validScore.put("math", math);
        }
        if (map.get("english") != null) {
            english = map.get("english").toString();
            validScore.put("english", english);
        }
        if (map.get("chemistry") != null) {
            chemistry = map.get("chemistry").toString();
            validScore.put("chemistry", chemistry);
        }
        if (map.get("biology") != null) {
            biology = map.get("biology").toString();
            validScore.put("biology", biology);
        }
        if (map.get("politics") != null) {
            politics = map.get("politics").toString();
            validScore.put("politics", politics);
        }
        if (map.get("history") != null) {
            history = map.get("history").toString();
            validScore.put("history", history);
            subject = "文科";
        }
        if (map.get("physical") != null) {
            history = map.get("physical").toString();
            validScore.put("physical", history);
            subject = "理科";
        }
        if (map.get("geography") != null) {
            geography = map.get("geography").toString();
            validScore.put("geography", geography);
        }
        if (map.get("technology") != null) {
            technology = map.get("technology").toString();
            validScore.put("technology", technology);
        }
        if (map.get("comprehensiveScience") != null) {
            comprehensiveScience = map.get("comprehensiveScience").toString();
            validScore.put("comprehensiveScience", comprehensiveScience);
        }
        if (map.get("comprehensiveLiberalArts") != null) {
            comprehensiveLiberalArts = map.get("comprehensiveLiberalArts").toString();
            validScore.put("comprehensiveLiberalArts", comprehensiveLiberalArts);
        }
        if (map.get("totalScore") != null) {
            totalScore = Integer.parseInt(map.get("totalScore").toString());
        }
        //根据用户名去查地区
        //     UserInfo userInfo = userInfoService.queryLocationByUserName(userName);
        //1、如果是模拟考，根据总分获取排名(分文理科),统考区（已知往年文理科招生数据）
        if (rank == 0) {
            Calendar cal = Calendar.getInstance();
            int month = cal.get(Calendar.MONTH);
            if(month < 7){
                year = year -1;
            }
            if (!(province.equals(CommUtil.JIANGSU_PROVINCE) && year <= 2021)) {
                rank = volunteerService.getRankByScore(province, totalScore, subject, year);
            }
        }
        /**
         *  2、判断所属高考区
         *  (1)统考区（已知往年文理科招生数据）
         *  (2)2021新高考改革地区（未知选科后的数据）（广东、福建、河北、辽宁、江苏、湖南、湖北、重庆）
         *  (3)2021新高考改革地区（已知选科后的数据）（上海、浙江、北京、海南、山东、天津）：
         */
        int areaNum = CommonUtil.examArea(province);
        List<SchoolInfo> schoolInfoList = null;
        if (areaNum == CommUtil.UNKNOW_NEW_EXAMINATION_AREA) {
            if (province.equals(CommUtil.JIANGSU_PROVINCE)) {
                System.out.println("totalScore:"+totalScore);
                totalScore = totalScore * 480 / 750;
                System.out.println("totalScore1:"+totalScore);
            }
            //查询去年该分数对应的文科名次
            int rankArts = volunteerService.getRankByScore(province, totalScore, CommUtil.WENKE_SUBJECT, year);
            //查询去年该分数对应的理科名次
            int rankScience = volunteerService.getRankByScore(province, totalScore, CommUtil.LIKE_SUBJECT, year);
            System.out.println("文科排名："+rankArts);
            System.out.println("理科排名："+rankScience);
            if(rank > 0) {
                if (CommUtil.WENKE_SUBJECT.equals(subject)) {
                    rank = rank * rankArts / (rankArts + rankScience);
                } else {
                    rank = rank * rankScience / (rankArts + rankScience);
                }
            }
            else{
                if (CommUtil.WENKE_SUBJECT.equals(subject)) {
                    rank = rankArts;
                } else {
                    rank = rankScience;
                }
            }
            System.out.println("理科排名："+rankScience);
        }
        if (areaNum == CommUtil.UNIFIED_EXAMINATION_AREA) {
            schoolInfoList = schoolService.getSchoolInfoListReport(year,province,rank + 5000, rank - 5000, subject, "本科一批");
        } else {
            if(year == 2020){
                schoolInfoList = schoolService.getSchoolInfoListReport(year,province,rank + 5000, rank - 5000, subject, "本科一批");
            }
            else {
                schoolInfoList = schoolService.getSchoolInfoListReport(year,province, rank + 5000, rank - 5000, "", "本科一批");
            }
        }
        return RestResult.success(schoolInfoList);
    }


    /**
     * 一键生成
     * @param map
     * @return
     */
    /**
     @RequestMapping("/exportReport")
     public List<SchoolInfo> exportReportVoluntary(@RequestBody Map<String, Object> map) {
     String schoolString = "";
     String majorString = "";
     String userName = "";

     List<String> schoolNameList = null;
     if (map.get("schoolList") != null) {
     schoolString = map.get("schoolList").toString();
     schoolNameList = Arrays.asList(schoolString.split(","));
     }

     List<String> majorList = null;
     if (map.get("major") != null) {
     majorString = map.get("major").toString();
     majorList = Arrays.asList(majorString.split(","));
     }

     if (map.get("userName") != null) {
     userName = map.get("userName").toString();
     }
     //根据用户名去查地区
     UserInfo userInfo = userInfoService.queryLocationByUserName(userName);
     String province = userInfo.getLocation();
     String mode = userInfo.getMode();
     //根据学校名称去查询专业组
     HashMap<String,List<String>> schoolMajorMap = new HashMap<String,List<String>>();
     HashMap<String,HashMap<String,List<String>>>  schoolMajorGroupMap= new HashMap<String,HashMap<String,List<String>>>();
     int areaNum = CommonUtil.examArea(userInfo.getLocation());
     int groupNum = 0;
     int majorLimit = 0;
     //1.统考区（吉林、黑龙江、内蒙古、山西、河南、安徽、江西、广西、四川、云南、贵州、陕西、宁夏、甘肃、青海、新疆、西藏）
     //9个院校*6个专业
     if (areaNum == CommUtil.UNKNOW_NEW_EXAMINATION_AREA) {
     schoolMajorMap = queryMajor(schoolNameList,majorList,6);
     }
     //2、院校专业组志愿
     else{
     switch(province){
     //(1)江苏 本科：40个院校专业组*6个专业志愿 专科：40个院校专业组*6个专业志愿
     case "江苏"://(5)福建 本科：40个院校专业组志愿*6个专业 专科：40个院校专业组志愿*6个专业
     case "福建":
     groupNum = 40;
     majorLimit = 6;
     break;
     //(2)湖北 本科：45个院校专业组志愿*6个专业
     case "湖北":
     groupNum = 45;
     majorLimit = 6;
     break;
     //(3)湖南 本科：45个院校专业组志愿*6个专业 专科：30个院校专业组志愿*6个专业
     case "湖南":
     if("本科".equals(mode)) {
     groupNum = 45;
     }else{
     groupNum = 30;
     }
     majorLimit = 6;
     break;
     //(4)广东 本科：45个院校专业组志愿*6个专业 专科：25个院校专业组志愿*6个专业
     case "广东":
     if("本科".equals(mode)) {
     groupNum = 45;
     }else{
     groupNum = 25;
     }
     majorLimit = 6;
     break;
     //(6)上海 本科：24个院校专业组志愿*6个专业 专科：8个院校专业组志愿*6个专业
     case "上海":
     if("本科".equals(mode)) {
     groupNum = 24;
     }else{
     groupNum = 8;
     }
     majorLimit = 6;
     break;
     //(7)海南 本科：24个院校专业组志愿*6个专业 专科：10个院校专业组志愿*6个专业
     case "海南":
     if("本科".equals(mode)) {
     groupNum = 24;
     }else{
     groupNum = 10;
     }
     majorLimit = 6;
     break;
     //(8)天津 本科：50个院校专业组志愿*6个专业
     case "天津":
     groupNum = 50;
     majorLimit = 6;
     break;
     //(9)北京 本科：16个院校专业组志愿*6个专业
     case "北京":
     groupNum = 16;
     majorLimit = 6;
     break;
     //3、专业+院校
     //(1)浙江 本科：80个专业志愿
     case "浙江":
     majorLimit = 80;
     break;
     //(2)山东 本科：96个专业志愿
     case "山东":
     //(3)河北 本科：96个专业志愿 专科96个专业志愿
     case "河北":
     //(4)重庆 本科：96个专业志愿 专科：96个专业志愿
     case "重庆":
     majorLimit = 96;
     break;
     //(5)辽宁 本科：112个专业志愿 专科：60个专业志愿
     case "辽宁":
     majorLimit = 112;
     break;
     }
     schoolMajorGroupMap = queryMajorGroup(schoolNameList,majorList,majorLimit,groupNum);
     }
     List<SchoolInfo> schoolInfoList = new ArrayList<SchoolInfo>();
     if(schoolMajorMap != null && schoolMajorMap.size() > 0){
     for(Map.Entry<String, List<String>> entry : schoolMajorMap.entrySet()){
     SchoolInfo schoolInfo = new SchoolInfo();
     School school = new School();
     school.setSchool_code((entry.getKey()));
     schoolInfo.setSchool(school);
     schoolInfo.setMajor(entry.getValue());
     schoolInfoList.add(schoolInfo);
     }
     }
     if(schoolMajorGroupMap.size() > 0){
     for(Map.Entry<String,HashMap<String,List<String>>> entry : schoolMajorGroupMap.entrySet()){
     SchoolInfo schoolInfo = new SchoolInfo();
     School school = new School();
     school.setSchool_code((entry.getKey()));
     schoolInfo.setSchool(school);
     List<MajorGroup> majorGroupList = new ArrayList<MajorGroup>();
     for(Map.Entry<String, List<String>> entry1 : entry.getValue().entrySet()){
     MajorGroup majorGroup = new MajorGroup();
     majorGroup.setMajors(entry1.getValue());
     majorGroupList.add(majorGroup);
     }
     schoolInfoList.add(schoolInfo);
     }
     }


     return null;
     //    return schoolInfoList;
     }*/

}
