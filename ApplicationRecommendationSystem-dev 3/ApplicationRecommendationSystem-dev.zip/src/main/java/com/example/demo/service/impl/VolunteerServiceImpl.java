package com.example.demo.service.impl;

import com.example.demo.repository.VolunteerReportRepository;
import com.example.demo.service.VolunteerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author 11834
 */
@Service
public class VolunteerServiceImpl implements VolunteerService {
    @Autowired
    private VolunteerReportRepository volunteerReportRepository;

    @Override
    public int getRankByScore(String province, int totalScore, String subject, int year) {

        return volunteerReportRepository.getRankByScore(province,String.valueOf(totalScore), subject, String.valueOf(year));
    }

}
