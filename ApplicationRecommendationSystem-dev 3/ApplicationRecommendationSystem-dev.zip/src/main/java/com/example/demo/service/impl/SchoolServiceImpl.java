package com.example.demo.service.impl;

import com.example.demo.entity.neo4j.*;
import com.example.demo.repository.SchoolInfoRepository;
import com.example.demo.service.SchoolService;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.ogm.model.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;


/**
 * @author 11834
 */
@Slf4j
@Service
public class SchoolServiceImpl implements SchoolService {

    @Autowired
    private SchoolInfoRepository schoolInfoRepository;


    @Override
    public SchoolInfo getSchoolInfo(String name) {
        Result result = schoolInfoRepository.getSchoolInfo(name);
        School school = null;
        String educationWay = "";
        SchoolLabel schoolLabel = null;
        String city = "";
        String province = "";
        String educationType = "";
        boolean masterPoint = false;
        boolean doctorPoint = false;
        boolean laboratory = false;
        Map<String,Object> map = null;
        try{
            map = result.iterator().next();
        }
        catch(Exception e){
            log.error("学校信息缺失：{}",name);
            result = null;
        }

        if(result != null && map != null){
            if(map.get("school") != null) {
                school = (School) map.get("school");
            }
            if(map.get("educationWay") != null) {
                educationWay = map.get("educationWay").toString();
            }
            if(map.get("schoolLabel") != null) {
                schoolLabel = (SchoolLabel) map.get("schoolLabel");
            }
            if(map.get("city") != null) {
                city = map.get("city").toString();
            }
            if(map.get("province") != null) {
                province = map.get("province").toString();
            }
            if(map.get("educationType") != null) {
                educationType = map.get("educationType").toString();
            }
            if(map.get("educationWay") != null) {
                educationWay = map.get("educationWay").toString();
            }
        }
        List<String> laboratories = schoolInfoRepository.getSchoolLaboratoryByName(name);
        if(laboratories != null && laboratories.size() > 0){
            if(laboratories.get(0) != "\\"){
                laboratory = true;
            }
        }
        Result doctorMasterPointResult = schoolInfoRepository.getSchoolDoctorMasterPointByName(name);
        Map<String,Object> doctorMasterPointMap = null;
        try{
            doctorMasterPointMap = doctorMasterPointResult.iterator().next();
        }
        catch(Exception e){
            log.error("硕博士点信息缺失：{}",name);
            doctorMasterPointResult = null;
        }
        if(doctorMasterPointResult != null && doctorMasterPointMap != null){
            if(doctorMasterPointMap.get("masterPoint") != null && doctorMasterPointMap.get("masterPoint") != "/") {
                System.out.println("=========="+doctorMasterPointMap.get("masterPoint").toString());
                System.out.println("=====1====="+"/");
                System.out.println("=====2====="+(doctorMasterPointMap.get("masterPoint") == "/"));
                System.out.println("=====3====="+(doctorMasterPointMap.get("masterPoint") != "/"));
                int masterPointTmp =  Integer.parseInt(doctorMasterPointMap.get("masterPoint").toString());
                if(masterPointTmp > 0){
                    masterPoint = true;
                }
            }
            if(doctorMasterPointMap.get("doctorPoint") != null && doctorMasterPointMap.get("doctorPoint") != "/") {
                int doctorPointTmp =  Integer.parseInt(doctorMasterPointMap.get("doctorPoint").toString());
                if(doctorPointTmp > 0){
                    doctorPoint = true;
                }
            }
        }
        SchoolInfo schoolInfo = new SchoolInfo();
        schoolInfo.setEducationWay(educationWay);
        schoolInfo.setSchool(school);
        schoolInfo.setSchoolLabel(schoolLabel);
        schoolInfo.setCity(city);
        schoolInfo.setProvince(province);
        schoolInfo.setEducationType(educationType);
        schoolInfo.setLaboratory(laboratory);
        schoolInfo.setDoctorPoint(doctorPoint);
        schoolInfo.setMasterPoint(masterPoint);
        return schoolInfo;
    }

    @Override
    public List<Major> getMajorList(String name) {
        return schoolInfoRepository.getMajorListBySchoolName(name);
    }

    @Override
    public List<SchoolAdmission> getSchoolAdmissionList(String name, String province, String subject, String level) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        List<SchoolAdmission> schoolAdmissions = new ArrayList<SchoolAdmission>();
        //6月份后按照当年数据往前推算，6月份前从去年数据往前推算
        if(month > 6){
            for(int i = year;i > year - 6;i--){
                String minAdmissionScore = schoolInfoRepository.getMinAdmissionScore(name,province,level,subject,Integer.toString(i));
                SchoolAdmission schoolAdmission= schoolInfoRepository.getAdmissionByMinScore(name,province,level,subject,Integer.toString(i),minAdmissionScore);
                schoolAdmissions.add(schoolAdmission);
            }
        }
        else{
            for(int i = year-1;i > year - 6;i--){
                String minAdmissionScore = schoolInfoRepository.getMinAdmissionScore(name,province,level,subject,Integer.toString(i));
                SchoolAdmission schoolAdmission= schoolInfoRepository.getAdmissionByMinScore(name,province,level,subject,Integer.toString(i),minAdmissionScore);
                schoolAdmissions.add(schoolAdmission);
            }
        }
        return schoolAdmissions;
    }

    @Override
    public List<MajorAdmission> getSchoolMajorAdmission(String name,String province,String subject,String year) {
        Result result = schoolInfoRepository.getMajoAdmission(name,province,year,subject);
        List<MajorAdmission> majorAdmissions = new ArrayList<MajorAdmission>();
        if(result != null){
            Iterator<Map<String, Object>> iterator = result.iterator();
            while(iterator.hasNext()) {
                MajorAdmission majorAdmission = new MajorAdmission();
                Map<String, Object> map = iterator.next();
                if (map.get("id") != null) {
                    majorAdmission.setId(map.get("id").toString());
                }
                if (map.get("majorName") != null) {
                    majorAdmission.setMajorName(map.get("majorName").toString());
                }
                if (map.get("minScore") != null) {
                    majorAdmission.setMinScore(map.get("minScore").toString());
                }
                if (map.get("minRank") != null) {
                    majorAdmission.setMinRank(map.get("minRank").toString());
                }
                if (map.get("aveScore") != null) {
                    majorAdmission.setAveScore(map.get("aveScore").toString());
                }
                if (map.get("layer") != null) {
                    majorAdmission.setLayer(map.get("layer").toString());
                }
                majorAdmissions.add(majorAdmission);
            }
        }

        return majorAdmissions;
    }

    @Override
    public List<SchoolInfo> getSchoolInfoListReport(int year,String province,int maxRank, int minRank, String subject, String mode) {
        List<String> schoolNames = null;
        if(!subject.isEmpty()) {
            schoolNames = schoolInfoRepository.getSchoolByScoreRank(String.valueOf(year),province, maxRank, minRank, subject, mode);
        }
        else{
            schoolNames = schoolInfoRepository.getSchoolByScoreRankNoSubject(String.valueOf(year),province, maxRank, minRank, mode);
        }
        log.info("school names length:{}",schoolNames.size());
        List<SchoolInfo> schoolInfos = new ArrayList<>();
        if(schoolNames != null && schoolNames.size() > 0){
            for(String name:schoolNames){
                SchoolInfo schoolInfo = getSchoolInfo(name);
                if(schoolInfo.getSchool() != null){
                    schoolInfos.add(schoolInfo);
                }
            }
        }
        return schoolInfos;
    }
}
