package com.example.demo.entity;

import lombok.Data;

@Data
public class OpenId {
    private Integer id;

    private String openId;

    private Integer userId;
}
